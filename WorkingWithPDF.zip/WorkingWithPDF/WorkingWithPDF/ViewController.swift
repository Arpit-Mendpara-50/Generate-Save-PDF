//
//  ViewController.swift
//  WorkingWithPDF
//
//  Created by Arpit Mendpara on 24/05/19.
//  Copyright © 2019 Arpit Mendpara. All rights reserved.
//

import UIKit
import WebKit

class ViewController: UIViewController {
    
    var webView: WKWebView!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        createPDF()
    }
    
    
    @IBAction func showPDF(_ sender: UIButton) {
        webView = WKWebView()
//        webView.navigationDelegate = self
        view = webView
        loadPDF(filename: "file")
        
    }
    
    func createPDF() {
        let html = "<b>Hello <i>World!</i></b> <p>Generate PDF file from HTML in Swift</p><b><p>Extra content to generate two pages</p></b><b><p>Arpit</p></b><b><p>Arpit</p></b><b><p>Arpit</p></b><b><p>Arpit</p></b><b><p>Arpit</p></b><b><p>Arpit</p></b><b><p>Arpit</p></b><b><p>Arpit</p></b><b><p>Arpit</p></b><b><p>Arpit</p></b><b><p>Arpit</p></b><b><p>Arpit</p></b><b><p>Arpit</p></b><b><p>Arpit</p></b><b><p>Arpit</p></b><b><p>Arpit</p></b><b><p>Arpit</p></b><b><p>Arpit</p></b><b><p>Arpit</p></b><b><p>Arpit</p></b><b><p>Arpit</p></b><b><p>Arpit</p></b><b><p>Arpit</p></b><b><p>Arpit</p></b><b><p>Arpit</p></b><b><p>Arpit</p></b><b><p>Arpit</p></b><b><p>Arpit</p></b><b><p>Arpit</p></b><b><p>Arpit</p></b><b><p>Arpit</p></b>"
        let fmt = UIMarkupTextPrintFormatter(markupText: html)
        
        // 2. Assign print formatter to UIPrintPageRenderer
        
        let render = UIPrintPageRenderer()
        render.addPrintFormatter(fmt, startingAtPageAt: 0)
        
        // 3. Assign paperRect and printableRect
        
        let page = CGRect(x: 0, y: 0, width: 595.2, height: 841.8) // A4, 72 dpi
        let printable = page.insetBy(dx: 0, dy: 0)
        
        render.setValue(NSValue(cgRect: page), forKey: "paperRect")
        render.setValue(NSValue(cgRect: printable), forKey: "printableRect")
        
        // 4. Create PDF context and draw
        
        let pdfData = NSMutableData()
        UIGraphicsBeginPDFContextToData(pdfData, .init(x: 0, y: 0, width: 595.2, height: 841.8), nil)
        
        for i in 1...render.numberOfPages {
            UIGraphicsBeginPDFPage();
            let bounds = UIGraphicsGetPDFContextBounds()
            render.drawPage(at: i - 1, in: bounds)
        }
        
        UIGraphicsEndPDFContext();
        
        // 5. Save PDF file
        
        let documentsPath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
        
        pdfData.write(toFile: "\(documentsPath)/file.pdf", atomically: true)
    }
    
    func loadPDF(filename: String) {
        let documentsPath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
        let url = URL(fileURLWithPath: documentsPath, isDirectory: true).appendingPathComponent(filename).appendingPathExtension("pdf")
        let urlRequest = URLRequest(url: url)
        webView.load(urlRequest)
    }

}

